# Phase 7 – 15 likely viva questions with short answers

1. **What is the aim of your system?** To let customers request vehicles for selected dates and help admins manage vehicles and bookings.
2. **Which technologies did you use?** HTML, CSS, vanilla JavaScript, PHP 8, MySQL and XAMPP.
3. **What is CRUD?** Create, Read, Update and Delete. We use it for vehicles, users, bookings and messages.
4. **What is a primary key?** A unique row identifier, such as `vehicles.id`.
5. **What is a foreign key?** A link between tables, such as `bookings.vehicle_id` referencing `vehicles.id`.
6. **What is a SQL JOIN?** It combines related records; we JOIN bookings with users and vehicles to display names.
7. **What is PDO?** PHP Data Objects, used to connect to MySQL and execute parameterized queries.
8. **Why prepared statements?** SQL values are sent separately from SQL commands, which helps prevent SQL injection.
9. **How do you protect passwords?** Store `password_hash()` output and check it with `password_verify()`. We never store plain passwords.
10. **Why use sessions?** A PHP session remembers which user has logged in across different pages.
11. **What is CSRF protection?** A random session token is included in each POST form and verified before changing data.
12. **How do you stop double booking?** Query active `pending` or `approved` bookings: a conflict exists when `new_pickup <= existing_return` AND `new_return >= existing_pickup`.
13. **Why use a database transaction and lock?** We lock the vehicle row while checking overlap and inserting the booking, so two requests cannot reserve overlapping dates simultaneously.
14. **How is total price calculated?** PHP counts inclusive days and multiplies by `vehicles.price_per_day`. JavaScript only previews the amount.
15. **How do customer and admin differ?** Customer pages allow managing only their own pending bookings; admin pages require an administrator role and can manage system records.
