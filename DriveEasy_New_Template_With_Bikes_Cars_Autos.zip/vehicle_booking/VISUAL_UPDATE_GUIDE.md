# DriveEasy – Vehicle Photos + Modern Website Update

This update keeps the beginner-friendly HTML, CSS, JavaScript, PHP, PDO and MySQL structure.
It builds on the version with the cancellation/refund request feature.

## What's new?

- New premium responsive homepage with a large white-car hero photo, ghost lettering, search form, vehicle categories, featured cards, and a three-step explanation.
- New card and catalog layout across mobile and desktop.
- 12 additional demonstration vehicle listings, bringing the original 12 to 24 total, assuming all original rows are present.
- Two new vehicle categories: **Three-wheeler** and **Scooter** (8 total categories).
- Local WebP image assets in `uploads/vehicles/`; they are demonstration illustrations generated for the project, NOT verified photos of exact vehicle models or actual rental inventory.
- Existing booking, login, customer profile, admin, contact and refund features are preserved.

## IMPORTANT – Updating your existing XAMPP website

1. **Back up the old site folder** first: `C:\xampp\htdocs\vehicle_booking`.
2. In phpMyAdmin choose `vehicle_booking_db` → **Export** → **Go** to save a backup of your existing data.
3. Extract `vehicle_booking_visual_patch.zip`.
4. Open the extracted `vehicle_booking` folder. Copy all files and folders INSIDE it to `C:\xampp\htdocs\vehicle_booking\`. Choose **Replace files** when Windows asks. This patch does not replace your `config/db.php` or existing uploaded customer images.
5. Start **Apache** and **MySQL** in XAMPP.
6. Open `http://localhost/phpmyadmin/`, click **Import**, choose `C:\xampp\htdocs\vehicle_booking\database\catalog_upgrade.sql`, click **Go**.
7. Check the database `vehicle_booking_db` → `vehicles` → Browse. You should see the new `DEMO-2001` to `DEMO-2012` listings.
8. Open `http://localhost/vehicle_booking/` and press **Ctrl + F5** to refresh the CSS.
9. Visit `http://localhost/vehicle_booking/vehicles.php` and choose **Three-wheeler** or **Motorbike**.
10. Test the **View details** link and a customer booking using your existing login.

**Do not import `database.sql` again on an existing database.** Only import `catalog_upgrade.sql` for this visual update. It adds demo rows and fills missing example image filenames; it does not delete customers or bookings. Running it again uses `INSERT IGNORE` and will not duplicate the same new demo vehicle registrations.

## If the refund update was not installed yet

If the earlier refund update was not installed, import the existing `database/refund_upgrade.sql` **once** (on the old database, before using the refund pages). Do not repeat this migration after it succeeds. For a fresh installation, just use the complete `database.sql` from the full project.

## First-time installation (no existing website or database)

1. Extract `vehicle_booking_studio_full.zip` and put `vehicle_booking` in `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. Visit phpMyAdmin → Import → select `vehicle_booking/database/database.sql`. This includes both the existing sample database and the new catalogue.
4. In `config/db.php`, check database name `vehicle_booking_db`, host `127.0.0.1`, user `root`, password blank for a default XAMPP install.
5. Open `http://localhost/vehicle_booking/`.
6. Test the demo accounts described in `README.md`. Do not use those passwords for a production server.

## Replacing demo pictures with actual vehicle photos

The included pictures are locally stored, AI-created *illustrative demo imagery*, which may not depict the precise listed make/model. For real deployment:

1. Take or obtain licensed photos of the actual vehicle you intend to list.
2. Log in to the website as admin → **Manage vehicles** → **Edit**.
3. Choose a JPG, PNG or WebP image (2 MB maximum) and save.
4. Your uploaded photo becomes the listing photo. The update script only sets missing images; it does not overwrite uploaded images.

No images load from a CDN, and the project works offline after importing the database.

## Common problems

| Problem | What to check |
|---|---|
| 404 Not Found | `index.php` must be at `C:\xampp\htdocs\vehicle_booking\index.php`; no extra nested folder. |
| Old website colours | Press Ctrl+F5 and check `assets/css/style.css` was replaced. |
| No three-wheelers | Import `database/catalog_upgrade.sql` into the XAMPP MySQL server. |
| Image broken | Check `uploads/vehicles/demo-auto-street.webp` exists and SQL image filename matches. |
| MySQL connection failed | Run MySQL in XAMPP and review `config/db.php`. |
| PHP warnings | Check the expected database columns and use the corrected `profile.php` in the complete project. |

## Educational note

This is a student booking demonstration. Prices and vehicle entries are sample data. It does not charge money, verify actual vehicle availability outside the demo data, or process a bank refund. The existing admin refund review workflow only records manual outcomes.
