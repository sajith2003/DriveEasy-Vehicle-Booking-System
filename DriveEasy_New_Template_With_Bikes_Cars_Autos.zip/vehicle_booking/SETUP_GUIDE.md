# Step-by-step XAMPP and MySQL database connection

## A. Install and start XAMPP

**Windows:** Download XAMPP from the official Apache Friends website. Install to `C:\xampp`. Run **XAMPP Control Panel** and click **Start** next to **Apache** and **MySQL**. Their rows should show running/green.

**macOS/Linux:** Install a compatible XAMPP package and start Apache and MariaDB/MySQL using the XAMPP manager or its start script. The corresponding `htdocs` folder is usually under `/Applications/XAMPP/xamppfiles/htdocs/` (macOS) or `/opt/lampp/htdocs/` (Linux).

## B. Place the project under htdocs

1. Extract `vehicle_booking_full.zip`.
2. Make sure the extracted folder is called **`vehicle_booking`** (not `vehicle_booking_full` and not `vehicle_booking/vehicle_booking`).
3. Windows final location: `C:\xampp\htdocs\vehicle_booking\index.php`.
4. Linux/macOS: copy `vehicle_booking` into the XAMPP `htdocs` directory.

## C. Import the MySQL database using phpMyAdmin

1. Open **`http://localhost/phpmyadmin/`**.
2. Choose the **Import** tab. (The SQL file creates the database for you.)
3. Click **Choose File**, browse to `C:\xampp\htdocs\vehicle_booking\database\database.sql`.
4. Click **Go** at the bottom.
5. In the left sidebar click **vehicle_booking_db**.
6. Check that six tables exist: **users, categories, vehicles, bookings, messages, refund_requests**.
7. Click **vehicles → Browse**. You should see **12 sample vehicles**.
8. If the database exists with incompatible old tables, export a backup and create a fresh database before importing. Avoid overwriting personal data.

**Alternative command line (Windows XAMPP Command Shell):**

```bash
mysql -u root -p < C:\xampp\htdocs\vehicle_booking\database\database.sql
```

If the root password is empty, run `mysql -u root < C:\xampp\htdocs\vehicle_booking\database\database.sql` instead. On Linux/macOS, use the XAMPP MySQL command path and absolute SQL file path.

## D. Connect PHP to MySQL

Open `vehicle_booking/config/db.php`:

```php
$dbHost = '127.0.0.1';
$dbPort = '3306';
$dbName = 'vehicle_booking_db';
$dbUser = 'root';
$dbPassword = '';
```

These match the **default local XAMPP MySQL settings**. If your own MySQL server uses port **3307**, change `$dbPort` to `3307`. If you gave root an actual password, put it in `$dbPassword`.

`$pdo = new PDO(...)` establishes the connection. Every page reaches this file via `includes/functions.php`; you do not need to connect the database separately in each PHP page.

`BASE_URL` is set to `/vehicle_booking/`. Only change it if you choose a different folder name.

## E. Image upload permissions

Create/check `vehicle_booking/uploads/vehicles/` and make it writable by Apache/PHP. In normal Windows XAMPP it is writable automatically. On Linux/macOS, grant the web server user write permission to this folder only; do **not** use `chmod -R 777` on the entire website.

The folder includes `.htaccess` to block executing uploaded PHP or other scripts on Apache. Only JPEG, PNG and WebP images up to **2 MB** are accepted.

## F. Open the system

- Website: **`http://localhost/vehicle_booking/`**
- Admin: **`http://localhost/vehicle_booking/admin/dashboard.php`** (login first)
- phpMyAdmin: **`http://localhost/phpmyadmin/`**

**Admin login:** `admin@vehicle.test` / `Admin@12345`

**Customer login:** `customer1@vehicle.test` / `Customer@12345`

Other demo customers: `customer2@vehicle.test` through `customer5@vehicle.test`, all with `Customer@12345`.

## G. Demonstrate the completed website

**Customer workflow:** Register → Log in → Vehicles → Filter → Vehicle details → Choose date range → Request booking → My bookings → Edit or Cancel while pending → Update profile.

**Admin workflow:** Log in as admin → Dashboard → Vehicles: Add, Edit, Delete → Bookings: Approve, Reject, Complete, Delete → Customers: Edit/Disable → Messages: Read/Delete.

**Important test:** Login as `customer1@vehicle.test`, choose **Toyota Aqua**, and select the sample booking's exact occupied dates. A new request must be rejected with an overlap message. Existing sample bookings are dated **relative to the SQL import date**, so look at the `bookings` table to find the current occupied dates.

## H. Troubleshooting

| Issue | What to do |
|---|---|
| Apache fails to start / port 80 | Check IIS, Skype, other Apache or web servers. Stop the competing service or change Apache port and visit `http://localhost:8080/vehicle_booking/` if configured for 8080. |
| MySQL fails to start / port 3306 | Stop another MySQL service or change the MySQL listening port; then update `$dbPort` to that port (for example `3307`). |
| `Database connection failed` | Start MySQL, confirm DB `vehicle_booking_db`, check host, port, username, password in `config/db.php`. |
| `Access denied for user root` | Your root password may not be empty. Enter the correct password or use a local database user you created. |
| Blank white PHP page | Look at `C:\xampp\apache\logs\error.log`; for local debugging only set `display_errors=On` in your PHP configuration and restart Apache. Turn it off after debugging. |
| Upload fails | Check `uploads/vehicles/` exists and is writable; file must be JPG/PNG/WebP under 2 MB. Check `upload_max_filesize` and `post_max_size` in `php.ini`. |
| Login appears forgotten | Enable browser cookies; confirm sessions are enabled; use the same host (`localhost` vs `127.0.0.1`) consistently. |
| CSS links fail / 404 | Ensure the folder is exactly `htdocs/vehicle_booking/` and `BASE_URL` matches it. |
| Reimport creates duplicates | Use a fresh DB for a clean installation. This seed SQL uses `INSERT IGNORE`, so it will not reset existing demo records. |
| 'could not find driver' | Enable `pdo_mysql` in your XAMPP `php.ini`, then restart Apache. |

## I. Database backup and team sharing

**phpMyAdmin backup:** Choose **vehicle_booking_db** → **Export** → **Quick** → **SQL** → **Go**. Keep the exported SQL file. This contains your live bookings and new customers, unlike the original `database.sql` sample seed file.

Share the project by ZIP or Git and include an exported copy of the database. Do not publish real passwords, credentials or customer information.

## J. Future extensions

Online payments, email notifications, PDF invoices, reviews/ratings, availability calendar and automated reporting are good future improvements; they are intentionally outside the beginner version.

## K. Cancellation / refund feature (new)

For the additional refund-review workflow, see **REFUND_SETUP.md**. For an existing database, back up and import **database/refund_upgrade.sql** *once*. Do not re-import the sample database.sql into your live database. No actual online payment or automatic refund is made.
