# DriveEasy – Premium Vehicle Booking System

**Updated design:** responsive light-blue studio-style homepage, 12 local demo vehicle image assets, category browsing, and 12 new sample vehicles including auto-rickshaws, motorbikes and scooters.

All interface code uses basic HTML, CSS, vanilla JavaScript, PHP and MySQL (PDO) with no frameworks. The existing customer booking, admin and refund-review flows are maintained.

**Important:** Images are AI-generated illustrative demo visuals, not verified photos of the particular models. Sample prices and availability are for university demonstration. Actual online payment and automatic refunds are not implemented.

For the exact safe upgrade steps for an existing XAMPP installation, start with [VISUAL_UPDATE_GUIDE.md](VISUAL_UPDATE_GUIDE.md).

---

## Project details

**University group project • PHP 8 + MySQL • XAMPP • Works offline**

## What it does

- Guest: home page, browse and filter vehicles, view details, send contact message.
- Customer: register, log in, search vehicles, request date-range bookings, view, edit or cancel pending bookings, edit profile and password.
- Admin: dashboard statistics, vehicle add/edit/soft-delete with image upload, approve/reject/complete/delete bookings, edit/disable customers, read/delete contact messages.
- Validation: browser checks plus PHP checks; PDO prepared SQL; sessions, CSRF and escaped output.
- Prevents overlapping `pending` or `approved` bookings for the same vehicle. Pickup and return dates count as chargeable days.
- Real payment gateway, real email delivery, and online image sources are deliberately **not** included.
- Cancellation reasons and customer refund requests: admin can approve/reject with notes and record a completed **manual** refund; no funds move within the app.

## Refund feature

Customer: cancel a pending booking with a reason, optionally request refund; for approved bookings, request cancellation/refund for admin review; or request refund after cancellation. Admin: Refund requests → review reason → approve an eligible amount or reject with explanation → after an **external manual payment**, record a refund reference and mark refunded. See `REFUND_SETUP.md`.

**Existing installations:** import `database/refund_upgrade.sql` **once**, not `database.sql` again. Back up your database first. New installations can use the updated `database.sql` which includes 6 tables.

## Demo login details (local use ONLY)

| Account | Email | Password |
|---|---|---|
| Admin | `admin@vehicle.test` | `Admin@12345` |
| Customer 1 | `customer1@vehicle.test` | `Customer@12345` |
| Customer 2–5 | `customer2@vehicle.test` … `customer5@vehicle.test` | `Customer@12345` |

**Change these passwords before using the project beyond a local classroom demo.**

## Quick start

1. Install XAMPP; start Apache and MySQL.
2. Copy the folder named `vehicle_booking` to `C:\xampp\htdocs\vehicle_booking` on Windows.
3. Open `http://localhost/phpmyadmin/` → **Import** → choose `database/database.sql` → **Go**.
4. For a default XAMPP install, `config/db.php` uses host `127.0.0.1`, port `3306`, database `vehicle_booking_db`, user `root`, empty password.
5. Open `http://localhost/vehicle_booking/` in a browser.
6. Log in with either demo account above, or register a new customer.

For a detailed step-by-step explanation, see **SETUP_GUIDE.md**.

## Files

- `config/db.php` — single PDO database connection and session startup.
- `includes/` — shared header, navbar, footer, authentication guards, CSRF and common functions.
- `index.php`, `vehicles.php`, `vehicle_details.php`, `book.php` — public and rental flow.
- `register.php`, `login.php`, `logout.php`, `profile.php` — accounts.
- `my_bookings.php`, `edit_booking.php`, `cancel_booking.php` — customer bookings.
- `contact.php` — stores messages in database.
- `admin/` — administration pages and vehicle upload helper.
- `assets/` — custom CSS, vanilla JavaScript and a local placeholder illustration.
- `uploads/vehicles/` — uploaded JPG, PNG, WebP (limited to 2 MB).
- `database/database.sql` — schema and sample data (1 admin, 5 customers, 8 categories, 24 vehicles, 10 bookings).
- `database/refund_upgrade.sql` — upgrade only for existing databases; adds cancellation reason and refund requests (without deleting data).

## Notes

- Booking statuses: `pending`, `approved`, `rejected`, `cancelled`, `completed`.
- Active booking = `pending` or `approved`. Admin cannot delete a vehicle with active bookings, and cannot disable a customer with active bookings.
- Customer deletion is implemented as **deactivation** (`users.is_active = 0`), and vehicle deletion as **soft delete** (`vehicles.is_deleted = 1`) to keep history.
- Uploaded image files are kept when a vehicle is updated/deactivated, to avoid breaking old references; removing unused files could be added later.
- For a deployment, use HTTPS, a least-privilege DB account, secure error logging, rate limiting and a stronger account administration flow. This is a local educational project, not production-ready.

## November 2026 — user photo and studio template update

For the new white/cyan homepage and 58 additional demo vehicles from your uploaded bike and car pictures, see **`INSTALL_NEW_DESIGN.md`** and **`IMAGE_CATALOGUE_NOTES.md`**. Existing databases need only `database/user_media_upgrade.sql` after any previously missing earlier upgrades; do not reimport the original base SQL. All new images are local/offline-capable.
