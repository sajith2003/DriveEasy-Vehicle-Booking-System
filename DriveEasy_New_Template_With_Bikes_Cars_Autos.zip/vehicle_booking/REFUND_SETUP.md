# Cancellation reason and refund review – Setup guide

## Important: this is a classroom demonstration, not a payment gateway

No card payment or online refund is implemented. The customer requests an amount equal to the booking price, but the admin must verify that payment was actually made and decide an eligible amount. **Approve** does not transfer money. **Mark refunded** is a record that the admin already transferred money outside the website.

## Install on your existing XAMPP website without erasing data

1. Back up your existing site folder `C:\xampp\htdocs\vehicle_booking\` and export the **current** `vehicle_booking_db` via phpMyAdmin → select the database → Export → Quick → SQL.
2. Copy the new/changed files from the patch ZIP into `C:\xampp\htdocs\vehicle_booking\`, keeping their folder structure. Choose **Replace** for the files in the patch. This does not overwrite your `config/db.php` or `profile.php`.
3. Start Apache and MySQL in XAMPP. Open **http://localhost/phpmyadmin/**.
4. In phpMyAdmin, choose **Import**, select **`database/refund_upgrade.sql`** from the copied project, and press **Go**. The SQL selects `vehicle_booking_db`, adds the `cancellation_reason` field and creates the `refund_requests` table. It does not delete customers, vehicles or bookings. **Run this upgrade only once.**
5. Click database `vehicle_booking_db` and check that there are now **6 tables**, including `refund_requests`. In `bookings`, check for the column `cancellation_reason`.
6. Open **http://localhost/vehicle_booking/my_bookings.php** while logged in as a customer.
7. Open **http://localhost/vehicle_booking/admin/refunds.php** while logged in as an admin.

> If the SQL says "Duplicate column name 'cancellation_reason'", you probably ran the upgrade already. Check the table and the column instead of running it again.

## Test (beginner-friendly)

**Test A: pending booking**
1. Customer logs in → **My bookings** → find a `pending` booking.
2. Enter a cancellation reason (10+ characters), tick **Also request a refund**, and click **Cancel booking**.
3. The booking changes to `cancelled`, and a refund request appears as `pending`.
4. Admin goes to **Refund requests**, reads the reason, verifies payment outside the website and chooses **Approve** with an amount, or **Reject** with a reason.
5. If approved, admin makes an actual refund manually (outside this software), adds a payment/reference number and clicks **Mark refunded**. Customer can see status and admin note.

**Test B: approved booking**
1. Customer → **My bookings** → find an `approved` booking → **Request cancellation & refund**.
2. Type the reason and submit. The booking remains approved while admin decides.
3. If admin approves, the booking becomes `cancelled`. If admin rejects, the booking stays approved.

**Test C: cancelled booking**
1. Customer → find a cancelled booking without an existing refund request → **Request refund**.
2. Enter reason → submit. Admin reviews as above.

## Key rules

- Only the customer who owns a booking can request a refund for it.
- Pending bookings can be cancelled directly. Approved bookings require admin review before cancellation.
- Only one refund request is allowed per booking.
- Admin must explain a rejection; approval can be partial (not more than the requested amount).
- The program does not know whether payment was received. Approval must never be interpreted as proof of payment or actual refund.
- Bookings with refund requests cannot be deleted, preserving the history.

## Files changed / added

`cancel_booking.php`, `my_bookings.php`, `refund_request.php`, `admin/refunds.php`, `admin/refund_update.php`, `admin/booking_update.php`, `admin/booking_delete.php`, `admin/dashboard.php`, `admin/nav.php`, `assets/css/style.css`, and `database/refund_upgrade.sql`.

The **full ZIP** also contains an updated `database/database.sql` for *new installations only*, plus the previously corrected `profile.php`. If your project is already installed, use the **patch ZIP and refund_upgrade.sql** instead of importing the full `database.sql` again.
