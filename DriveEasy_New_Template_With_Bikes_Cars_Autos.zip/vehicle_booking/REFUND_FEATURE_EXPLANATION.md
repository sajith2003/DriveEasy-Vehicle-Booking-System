# Feature: Cancel Booking + Request Refund

## Why this is useful

Customers sometimes cancel a trip because of personal, medical or travel problems. A cancellation reason lets the administrator decide whether the booking is eligible for a full or partial refund under the business cancellation policy. This adds realistic customer-service workflow to a beginner PHP university project.

## Who does what?

**Customer:** explains cancellation, sends refund request, views refund status.

**Admin:** reads the reason, checks whether the customer actually paid, decides whether to approve or reject and can leave a written note. If approved, the admin pays outside the website and records a reference number.

## Example

Customer: "I need to cancel booking #12 because my hospital appointment was postponed. I already paid LKR 8,500. Please consider a refund."

Admin: reads the reason, checks payment evidence and policy, approves LKR 8,500 (or a smaller eligible amount), and the booking becomes cancelled. The admin transfers the money through a bank or another external method, and only **then** marks the request as **refunded**.

## Status meanings

- **Pending**: waiting for admin decision.
- **Approved**: admin accepted the refund request and selected an amount. **Money has not automatically been sent.**
- **Rejected**: admin declined and wrote a reason; the customer can read it.
- **Refunded**: admin marked that an external/manual payment was completed and supplied a reference.

The project does **not** collect payments, send bank transfers, confirm money received or guarantee an actual refund. Financial details are for a student demonstration only.
