# Supplied Vehicle Images and Cataloguing Notes

**Image sources:**

1. `BikeVault-LK-bike-list-with-photos.docx` — 43 motorcycle entries. Each Word table row has one embedded image. The original file labels entries as **Photo** or **Illustration**.
2. `Car images.zip` — 15 files showing a mixture of sports cars, motorcycle photographs, autos and three-wheeled mobility vehicles. The filenames include several Unsplash photographer attributions.
3. The uploaded Toyota Raize-themed screenshot is **a visual design reference**, not a photo inserted into the website and not used as DriveEasy branding.

All actual embedded images were extracted and converted to local `.webp` for a consistent image size. The photo content and any embedded credits/watermarks are retained. A CSV mapping of all 58 catalogue items is available as `assets/USER_MEDIA_MANIFEST.csv`.

For the vintage entries (older than 1980), initial rental status is `unavailable` by default. They remain visible as a historical collection but cannot be booked. For newer entries, the example prices are only classroom demonstration values. The uploaded images do not prove vehicle ownership or rental eligibility.

**Copyright:** user-supplied imagery is not necessarily licensed for public reuse. Verify licensing before making the site public or submitting assets beyond the intended course context.
