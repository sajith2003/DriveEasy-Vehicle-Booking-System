'use strict';
// Keep the header compact after the user scrolls. Also works if page loads mid-scroll.
const siteHeader = document.querySelector('.site-header');
if (siteHeader) {
  const updateHeader = () => siteHeader.classList.toggle('is-scrolled', window.scrollY > 24);
  window.addEventListener('scroll', updateHeader, { passive: true });
  updateHeader();
}
const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('.site-nav');
if (menuButton && menu) {
  menuButton.addEventListener('click', () => {
    const opened = menu.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(opened));
  });
}
document.querySelectorAll('[data-confirm]').forEach((form) => {
  form.addEventListener('submit', (event) => {
    if (!window.confirm(form.dataset.confirm || 'Are you sure?')) event.preventDefault();
  });
});
const flash = document.querySelector('[data-flash]');
if (flash) window.setTimeout(() => flash.classList.add('fade-out'), 6000);
// Small interactive product image gallery on the new homepage.
// Each image file is local so the website works offline after setup.
const heroPhoto = document.querySelector('#tx-hero-photo');
const heroName = document.querySelector('#tx-photo-name');
const heroButtons = document.querySelectorAll('[data-hero-image]');
if (heroPhoto && heroButtons.length) {
  heroButtons.forEach(button => {
    button.setAttribute('aria-pressed', String(button.classList.contains('is-current')));
    button.addEventListener('click', () => {
      const source = button.dataset.heroImage;
      if (!source) return;
      const nextPhoto = new Image();
      nextPhoto.onload = () => {
        heroPhoto.classList.add('tx-changing');
        heroPhoto.src = source;
        heroPhoto.alt = button.dataset.heroAlt || 'Showcase vehicle';
        if (heroName) heroName.textContent = button.dataset.heroTitle || 'DriveEasy collection';
        heroButtons.forEach(item => {
          const active = item === button;
          item.classList.toggle('is-current', active);
          item.setAttribute('aria-pressed', String(active));
        });
        window.requestAnimationFrame(() => window.requestAnimationFrame(() => heroPhoto.classList.remove('tx-changing')));
      };
      nextPhoto.src = source;
    });
  });
}
