-- DriveEasy user-uploaded photo catalogue upgrade (MySQL/MariaDB)
-- Import ONCE after importing database.sql, refund_upgrade.sql (if needed), and catalog_upgrade.sql (if needed).
-- Safe for an existing installation: no DROP, DELETE, TRUNCATE or overwrite of existing vehicles.
-- INSERT IGNORE avoids duplicating records identified by their unique demo registration numbers.
-- Registration numbers, rental prices and features are DEMONSTRATION values, not actual rental inventory.
USE vehicle_booking_db;
INSERT IGNORE INTO categories (name) VALUES ('Car'),('SUV'),('Luxury'),('Motorbike'),('Scooter'),('Three-wheeler'),('Van');

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Harley-Davidson WLA Liberator','Harley-Davidson','WLA Liberator',1942,'BV-DEMO-001',2,'Manual','Petrol',6500,'uploaded-bike-01.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Photo. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'BMW R75 with sidecar','BMW','R75 with sidecar',1941,'BV-DEMO-002',2,'Manual','Petrol',6500,'uploaded-bike-02.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Zündapp KS 750','Zündapp','KS 750',1941,'BV-DEMO-003',2,'Manual','Petrol',6500,'uploaded-bike-03.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Indian 741 Scout','Indian','741 Scout',1942,'BV-DEMO-004',2,'Manual','Petrol',6500,'uploaded-bike-04.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'BSA M20','BSA','M20',1940,'BV-DEMO-005',2,'Manual','Petrol',6500,'uploaded-bike-05.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Matchless G3L','Matchless','G3L',1941,'BV-DEMO-006',2,'Manual','Petrol',6500,'uploaded-bike-06.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Triumph 3HW','Triumph','3HW',1942,'BV-DEMO-007',2,'Manual','Petrol',6500,'uploaded-bike-07.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Photo. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Norton 16H / Big 4','Norton','16H / Big 4',1940,'BV-DEMO-008',2,'Manual','Petrol',6500,'uploaded-bike-08.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'IMZ / Ural M-72','IMZ / Ural','M-72',1941,'BV-DEMO-009',2,'Manual','Petrol',6500,'uploaded-bike-09.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Rikuo Type 97 Rikuo','Rikuo','Type 97 Rikuo',1935,'BV-DEMO-010',2,'Manual','Petrol',6500,'uploaded-bike-10.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Vincent Black Shadow','Vincent','Black Shadow',1950,'BV-DEMO-011',2,'Manual','Petrol',6500,'uploaded-bike-11.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Photo. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Triumph Bonneville T120','Triumph','Bonneville T120',1960,'BV-DEMO-012',2,'Manual','Petrol',6500,'uploaded-bike-12.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Norton Commando 850','Norton','Commando 850',1973,'BV-DEMO-013',2,'Manual','Petrol',6500,'uploaded-bike-13.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Honda CB750 Four','Honda','CB750 Four',1969,'BV-DEMO-014',2,'Manual','Petrol',6500,'uploaded-bike-14.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Photo. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'BSA Gold Star','BSA','Gold Star',1956,'BV-DEMO-015',2,'Manual','Petrol',6500,'uploaded-bike-15.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Harley-Davidson EL Knucklehead','Harley-Davidson','EL Knucklehead',1936,'BV-DEMO-016',2,'Manual','Petrol',6500,'uploaded-bike-16.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Royal Enfield Bullet 350 (classic)','Royal Enfield','Bullet 350 (classic)',1955,'BV-DEMO-017',2,'Manual','Petrol',6500,'uploaded-bike-17.webp','unavailable','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Historical collector item: booking is disabled by default.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Royal Enfield Bullet 350','Royal Enfield','Bullet 350',2024,'BV-DEMO-018',2,'Manual','Petrol',5000,'uploaded-bike-18.webp','available','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Bajaj Pulsar NS200','Bajaj','Pulsar NS200',2024,'BV-DEMO-019',2,'Manual','Petrol',5550,'uploaded-bike-19.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Yamaha YZF-R15 V4','Yamaha','YZF-R15 V4',2024,'BV-DEMO-020',2,'Manual','Petrol',7000,'uploaded-bike-20.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Honda CB500X','Honda','CB500X',2023,'BV-DEMO-021',2,'Manual','Petrol',3700,'uploaded-bike-21.webp','available','University demo catalogue: Adventure motorcycle reference from the user-provided BikeVault LK document. Image type in source: Photo. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Kawasaki Z900','Kawasaki','Z900',2024,'BV-DEMO-022',2,'Manual','Petrol',3350,'uploaded-bike-22.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Harley-Davidson Sportster S','Harley-Davidson','Sportster S',2023,'BV-DEMO-023',2,'Manual','Petrol',3900,'uploaded-bike-23.webp','available','University demo catalogue: Cruiser motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Ducati Scrambler Icon','Ducati','Scrambler Icon',2024,'BV-DEMO-024',2,'Manual','Petrol',4450,'uploaded-bike-24.webp','available','University demo catalogue: Scrambler motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'KTM 300 EXC','KTM','300 EXC',2024,'BV-DEMO-025',2,'Manual','Petrol',5000,'uploaded-bike-25.webp','available','University demo catalogue: Dirt motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Vespa Primavera 150','Vespa','Primavera 150',2024,'BV-DEMO-026',2,'Automatic','Petrol',5550,'uploaded-bike-26.webp','available','University demo catalogue: Scooter motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Scooter';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Zero Motorcycles SR/F','Zero Motorcycles','SR/F',2024,'BV-DEMO-027',2,'Manual','Electric',6100,'uploaded-bike-27.webp','available','University demo catalogue: Electric motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'TVS Apache RTR 200 4V','TVS','Apache RTR 200 4V',2024,'BV-DEMO-028',2,'Manual','Petrol',2800,'uploaded-bike-28.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Honda Dio','Honda','Dio',2024,'BV-DEMO-029',2,'Automatic','Petrol',3350,'uploaded-bike-29.webp','available','University demo catalogue: Scooter motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Scooter';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Yamaha FZ-S FI','Yamaha','FZ-S FI',2024,'BV-DEMO-030',2,'Manual','Petrol',3900,'uploaded-bike-30.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Suzuki Gixxer SF 250','Suzuki','Gixxer SF 250',2023,'BV-DEMO-031',2,'Manual','Petrol',5350,'uploaded-bike-31.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Royal Enfield Himalayan 450','Royal Enfield','Himalayan 450',2024,'BV-DEMO-032',2,'Manual','Petrol',5900,'uploaded-bike-32.webp','available','University demo catalogue: Adventure motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Bajaj CT 100','Bajaj','CT 100',2024,'BV-DEMO-033',2,'Manual','Petrol',5550,'uploaded-bike-33.webp','available','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Honda CBR1000RR-R Fireblade','Honda','CBR1000RR-R Fireblade',2024,'BV-DEMO-034',2,'Manual','Petrol',7000,'uploaded-bike-34.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Yamaha YZF-R1','Yamaha','YZF-R1',2024,'BV-DEMO-035',2,'Manual','Petrol',3700,'uploaded-bike-35.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Kawasaki Ninja ZX-10R','Kawasaki','Ninja ZX-10R',2024,'BV-DEMO-036',2,'Manual','Petrol',4250,'uploaded-bike-36.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Ducati Panigale V4','Ducati','Panigale V4',2024,'BV-DEMO-037',2,'Manual','Petrol',4800,'uploaded-bike-37.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'BMW S 1000 RR','BMW','S 1000 RR',2024,'BV-DEMO-038',2,'Manual','Petrol',5350,'uploaded-bike-38.webp','available','University demo catalogue: Superbike motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Triumph Street Triple RS','Triumph','Street Triple RS',2024,'BV-DEMO-039',2,'Manual','Petrol',5000,'uploaded-bike-39.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'KTM 1290 Super Duke R','KTM','1290 Super Duke R',2024,'BV-DEMO-040',2,'Manual','Petrol',5550,'uploaded-bike-40.webp','available','University demo catalogue: Naked motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Royal Enfield Interceptor 650','Royal Enfield','Interceptor 650',2024,'BV-DEMO-041',2,'Manual','Petrol',6100,'uploaded-bike-41.webp','available','University demo catalogue: Vintage motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Honda Africa Twin','Honda','Africa Twin',2024,'BV-DEMO-042',2,'Manual','Petrol',3700,'uploaded-bike-42.webp','available','University demo catalogue: Adventure motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'BMW R 1250 GS','BMW','R 1250 GS',2024,'BV-DEMO-043',2,'Manual','Petrol',4250,'uploaded-bike-43.webp','available','University demo catalogue: Adventure motorcycle reference from the user-provided BikeVault LK document. Image type in source: Illustration. Price and registration are illustrative, not a real rental offer. Ask the administrator to verify details before any real booking.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Yellow City Tuk-Tuk','Demo','Yellow Tuk-Tuk',2024,'PIC-DEMO-001',3,'Manual','Petrol',3400,'uploaded-showcase-01.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Three-wheeler';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Orange Racing Motorcycle','Demo','Track Bike',2024,'PIC-DEMO-002',2,'Manual','Petrol',5100,'uploaded-showcase-02.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Orange Sports Coupe','Demo','Orange Coupe',2024,'PIC-DEMO-003',2,'Automatic','Petrol',35000,'uploaded-showcase-03.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Luxury';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Festival Decorated Auto','Demo','Decorated Auto',2023,'PIC-DEMO-004',3,'Manual','Petrol',3300,'uploaded-showcase-04.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Three-wheeler';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Red Three-Wheeler','Demo','Red Auto',2024,'PIC-DEMO-005',3,'Manual','Petrol',3200,'uploaded-showcase-05.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Three-wheeler';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Woodland Street Motorbike','Demo','Street Bike',2024,'PIC-DEMO-006',2,'Manual','Petrol',4200,'uploaded-showcase-06.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Harley-Davidson Style Cruiser','Harley-Davidson','Cruiser',2023,'PIC-DEMO-007',2,'Manual','Petrol',9100,'uploaded-showcase-07.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Blue Sport Sedan','Demo','Blue Sedan',2023,'PIC-DEMO-008',5,'Automatic','Petrol',11000,'uploaded-showcase-08.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Car';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Red Sports Car','Demo','Red Sports Car',2024,'PIC-DEMO-009',2,'Automatic','Petrol',37000,'uploaded-showcase-09.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Luxury';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Red Racing Superbike','Demo','Red Superbike',2023,'PIC-DEMO-010',2,'Manual','Petrol',5900,'uploaded-showcase-10.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Midnight Performance Car','Demo','Night Supercar',2024,'PIC-DEMO-011',2,'Automatic','Petrol',38000,'uploaded-showcase-11.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Luxury';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'White Performance Coupe','Demo','White Supercar',2024,'PIC-DEMO-012',2,'Automatic','Petrol',34000,'uploaded-showcase-12.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Luxury';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Yellow Sports Bike','Demo','Yellow Sportbike',2024,'PIC-DEMO-013',2,'Manual','Petrol',5000,'uploaded-showcase-13.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Motorbike';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'Green Electric Microcar','Demo','Green 3-Wheeler',2024,'PIC-DEMO-014',2,'Automatic','Electric',4000,'uploaded-showcase-14.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Three-wheeler';

INSERT IGNORE INTO vehicles (category_id,name,brand,model,year,registration_no,seats,transmission,fuel_type,price_per_day,image,status,description)
SELECT id,'White Cargo Three-Wheeler','Demo','Cargo Auto',2024,'PIC-DEMO-015',2,'Automatic','Electric',4200,'uploaded-showcase-15.webp','available','University demo listing created from an image in the user-provided Car images.zip. The model name, daily price and registration are illustrative and do not establish actual ownership, rental availability or vehicle specifications.' FROM categories WHERE name='Three-wheeler';
