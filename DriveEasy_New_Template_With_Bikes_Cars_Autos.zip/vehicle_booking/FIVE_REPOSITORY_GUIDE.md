# DriveEasy: Five Repository / Group-Member Split

## Important

**Five repositories are five *contribution areas*, not five independent working websites.** They depend on the shared database, PHP includes and CSS. To run the application, combine each repository’s `vehicle_booking/` contents into one project at `C:\xampp\htdocs\vehicle_booking\`, or use the single full-project ZIP.

Do not create five separate MySQL databases. All features use `vehicle_booking_db`.

| Repository | Group member | Responsibility | Difficulty | Files |
|---|---|---|---|---|
| 1. `01_public_website` | Member 1 | Public website and vehicle catalogue | **Easy** | 19 |
| 2. `02_customer_accounts` | Member 2 | Registration, login and customer profile | **Easy–Medium** | 7 |
| 3. `03_bookings_refunds` | Member 3 | Booking dates, cancellation and refund request | **Hard** | 6 |
| 4. `04_admin_management` | Member 4 | Admin dashboard and CRUD management | **Medium–Hard** | 18 |
| 5. `05_database_shared` | Member 5 | MySQL database, shared layout and integration | **Medium** | 13 |

## Which repository is easiest to present?

**Repository 1 — Public Website & Vehicle Catalogue is the easiest.** You can show the homepage and vehicle cards in the browser, explain the HTML/CSS layout and simple search/filter steps without discussing complicated transactions.

### Simple university demo script (about 2 minutes)

1. "Our project is DriveEasy, a vehicle-booking website built using PHP, MySQL, HTML, CSS and JavaScript."
2. "I worked on the homepage and vehicle catalogue. Customers can explore vehicle categories, daily prices, and photos."
3. Open Home > Our vehicles > a category > a vehicle details page.
4. "The vehicle cards are generated from records in the MySQL vehicles table using PHP. CSS makes the layout responsive for different screen sizes."
5. Scroll down: "The top menu automatically reduces in height with a small JavaScript scroll listener."
6. "Booking and payment decisions are handled in other group modules. This is a local university demonstration, not a production payment system."

## Team integration procedure

1. Each member develops their assigned files in their own repository and tests changes using a local copy of the FULL site.
2. Group integration: merge **all five** `vehicle_booking/` folders into one shared project. Keep relative paths exactly as supplied.
3. Back up your working site and MySQL database before replacing any files.
4. Update the SQL only when setting up the database or when a new migration is required. Do not repeatedly import `database.sql`.
5. Run one integrated website: `http://localhost/vehicle_booking/` (Apache and MySQL running).
6. Test customer login, vehicle browsing, booking, admin add/remove vehicles and refund workflow together.

## What each member can say in the viva

### Member 1: Public website and vehicle catalogue
EASIEST: show homepage, responsive design, categories, catalogue filters, then open vehicle details. Explain HTML + CSS + PHP SELECT query. No need to discuss booking transactions.

### Member 2: Registration, login and customer profile
Present the registration form, session login, password hashing, and editing a profile.

### Member 3: Booking dates, cancellation and refund request
Explain date validation, overlapping-booking prevention, cancellation reason, and refund request. Hardest business logic.

### Member 4: Admin dashboard and CRUD management
Show how admin adds, edits or removes vehicles, reviews bookings, customers, contact messages, and refund requests.

### Member 5: MySQL database, shared layout and integration
Explain SQL tables/relationships, PDO connection, shared header/footer, the small-on-scroll header, and contact form.

## Full-project launch

The five split ZIPs are for teamwork and version control; use `driveeasy_compact_complete.zip` to run the complete application immediately.
