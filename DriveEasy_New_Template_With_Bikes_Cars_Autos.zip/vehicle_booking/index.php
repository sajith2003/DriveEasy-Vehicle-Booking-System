<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Find your next ride';
$allCategories = categories($pdo);
$vehicles = $pdo->query("SELECT v.*, c.name AS category FROM vehicles v
    JOIN categories c ON v.category_id = c.id
    WHERE v.is_deleted=0 AND v.status='available'
    ORDER BY CASE WHEN v.image IS NULL OR v.image='' THEN 1 ELSE 0 END, v.id DESC LIMIT 8")->fetchAll();
$totalVehicles = (int)$pdo->query("SELECT COUNT(*) FROM vehicles WHERE is_deleted=0 AND status='available'")->fetchColumn();
$categoryIcons = ['Car'=>'🚘','SUV'=>'🚙','Van'=>'🚐','Motorbike'=>'🏍️','Pickup'=>'🛻','Luxury'=>'✦','Three-wheeler'=>'🛺','Scooter'=>'🛵'];
$categoryPhotos = [
    'Car'=>'uploaded-showcase-08.webp',
    'SUV'=>'demo-suv-mountain.webp',
    'Van'=>'demo-van-white.webp',
    'Motorbike'=>'uploaded-bike-20.webp',
    'Pickup'=>'demo-suv-forest.webp',
    'Luxury'=>'uploaded-showcase-12.webp',
    'Three-wheeler'=>'uploaded-showcase-01.webp',
    'Scooter'=>'uploaded-bike-26.webp'
];
require __DIR__ . '/includes/header.php';
?>
<main class="toyota-page">
  <section class="tx-hero" aria-label="Discover DriveEasy vehicles">
    <div class="container tx-hero-grid">
      <div class="tx-copy">
        <span class="tx-overline"><span class="tx-overline-mark"></span> DRIVEEASY / SRI LANKA</span>
        <p class="tx-small">THE FREEDOM TO MOVE</p>
        <h1>Every drive<br>starts <span>here.</span></h1>
        <p class="tx-summary">Find your perfect match. From elegant cars to spirited bikes and everyday three-wheelers, explore a fleet designed for the way you move.</p>
        <div class="tx-actions">
          <a href="<?= h(url('vehicles.php')) ?>" class="tx-button tx-primary">Explore our vehicles <span aria-hidden="true">↗</span></a>
          <a href="#tx-collection" class="tx-button tx-quiet">Discover the collection <span aria-hidden="true">↓</span></a>
        </div>
        <div class="tx-proof"><strong><?= $totalVehicles ?></strong><span>demo vehicles<br>available to explore</span><span class="tx-proof-rule" aria-hidden="true"></span><span>01 / STYLE<br>02 / FREEDOM</span></div>
      </div>
      <div class="tx-visual">
        <div class="tx-pane tx-pane-one" aria-hidden="true"></div><div class="tx-pane tx-pane-two" aria-hidden="true"></div><div class="tx-pane tx-pane-three" aria-hidden="true"></div>
        <span class="tx-word" aria-hidden="true">MOVE</span>
        <img id="tx-hero-photo" class="tx-hero-photo" src="<?= h(url('assets/images/showcase-white-coupe.webp')) ?>" alt="White performance car from the uploaded vehicle image collection" width="1450" height="910" fetchpriority="high">
        <div class="tx-photo-label"><span class="tx-label-dot"></span><strong id="tx-photo-name">Performance collection</strong><small>YOUR NEXT STORY STARTS HERE</small></div>
        <div class="tx-visual-vertical" aria-hidden="true">DRIVEEASY / 2026</div>
      </div>
    </div>
    <div class="container tx-slidebar" aria-label="Showcase vehicle pictures">
      <div class="tx-slide-heading"><span class="tx-section-code">SELECT YOUR VIEW</span><strong>Explore a different ride.</strong></div>
      <div class="tx-slide-controls">
        <button class="tx-slide-button is-current" type="button" data-hero-image="<?= h(url('assets/images/showcase-white-coupe.webp')) ?>" data-hero-title="Performance collection" data-hero-alt="White sports car">01 <span>SPORT</span></button>
        <button class="tx-slide-button" type="button" data-hero-image="<?= h(url('assets/images/showcase-orange-coupe.webp')) ?>" data-hero-title="Signature sports cars" data-hero-alt="Orange sports car">02 <span>STYLE</span></button>
        <button class="tx-slide-button" type="button" data-hero-image="<?= h(url('assets/images/showcase-auto.webp')) ?>" data-hero-title="Everyday three-wheelers" data-hero-alt="Yellow auto rickshaw">03 <span>CITY</span></button>
        <button class="tx-slide-button" type="button" data-hero-image="<?= h(url('assets/images/showcase-blue-sedan.webp')) ?>" data-hero-title="Comfortable city cars" data-hero-alt="Blue sedan at sunset">04 <span>TOUR</span></button>
      </div>
    </div>
  </section>

  <section class="tx-search" aria-label="Search vehicles">
    <div class="container">
      <form class="tx-search-form" method="get" action="<?= h(url('vehicles.php')) ?>">
        <div class="tx-search-intro"><span class="tx-search-icon" aria-hidden="true">⌕</span><span><strong>Find your ride</strong><small>Search the DriveEasy fleet</small></span></div>
        <div class="tx-search-field"><label for="tx-query">VEHICLE OR BRAND</label><input id="tx-query" name="q" placeholder="Toyota, Yamaha, Bajaj…"></div>
        <div class="tx-search-field"><label for="tx-category">VEHICLE TYPE</label><select name="category" id="tx-category"><option value="">All categories</option><?php foreach($allCategories as $cat): ?><option value="<?= (int)$cat['id'] ?>"><?= h($cat['name']) ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="tx-button tx-primary tx-search-submit">Search vehicles <span aria-hidden="true">→</span></button>
      </form>
    </div>
  </section>

  <section class="container tx-section" id="tx-collection">
    <div class="tx-heading"><div><span class="tx-section-code">01 / EXPLORE THE COLLECTION</span><h2>Choose your direction.</h2><p>Pick a category to find your perfect set of wheels.</p></div><a class="tx-view" href="<?= h(url('vehicles.php')) ?>">View all vehicles <span aria-hidden="true">↗</span></a></div>
    <div class="tx-category-grid">
      <?php foreach($allCategories as $cat): $photo=$categoryPhotos[$cat['name']] ?? 'demo-white-crossover.webp'; ?>
        <a class="tx-category" href="<?= h(url('vehicles.php?category=' . (int)$cat['id'])) ?>">
          <span class="tx-cat-photo"><img src="<?= h(vehicle_image($photo)) ?>" alt="Example <?= h($cat['name']) ?> vehicle" loading="lazy"></span>
          <span class="tx-cat-meta"><strong><?= h($cat['name']) ?></strong><span aria-hidden="true">↗</span></span>
        </a>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="tx-showroom"><div class="container tx-section">
    <div class="tx-heading"><div><span class="tx-section-code">02 / CURATED FOR YOU</span><h2>Find your next favourite.</h2><p>Vehicle photos come from your uploaded files and the included demo image collection.</p></div><a class="tx-view" href="<?= h(url('vehicles.php')) ?>">Full catalogue <span aria-hidden="true">↗</span></a></div>
    <div class="grid cards tx-fleet-cards">
      <?php foreach($vehicles as $vehicle): ?>
        <article class="card vehicle-card">
          <a class="card-image-link" href="<?= h(url('vehicle_details.php?id=' . (int)$vehicle['id'])) ?>" aria-label="View <?= h($vehicle['name']) ?>">
            <img class="vehicle-img" src="<?= h(vehicle_image($vehicle['image'])) ?>" alt="<?= h($vehicle['name']) ?> showcase image" loading="lazy"><span class="image-category"><?= h($vehicle['category']) ?></span>
          </a>
          <div class="card-content"><div class="card-small">DRIVEEASY COLLECTION • <?= h($vehicle['year']) ?></div><h3><?= h($vehicle['name']) ?></h3>
            <p class="card-specs"><span><?= h($vehicle['seats']) ?> seats</span><span><?= h($vehicle['transmission']) ?></span><span><?= h($vehicle['fuel_type']) ?></span></p>
            <div class="card-bottom"><p class="price"><?= h(money($vehicle['price_per_day'])) ?><small> / day</small></p><a class="round-arrow" href="<?= h(url('vehicle_details.php?id=' . (int)$vehicle['id'])) ?>" aria-label="View <?= h($vehicle['name']) ?> details">↗</a></div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div></section>

  <section class="container tx-section tx-how" id="how-it-works">
    <div class="tx-heading"><div><span class="tx-section-code">03 / SIMPLE BY DESIGN</span><h2>Book with confidence.</h2><p>Browse, choose dates and keep track of your request — all in one place.</p></div></div>
    <div class="tx-how-grid"><div><span>01</span><h3>Find your match.</h3><p>Browse cars, bikes, scooters and three-wheelers. Compare the photos, features and demo prices.</p></div><div><span>02</span><h3>Pick your dates.</h3><p>Choose your rental dates. The PHP booking logic checks for overlapping reservations.</p></div><div><span>03</span><h3>Stay in control.</h3><p>View your bookings, request cancellation or a refund review and read the administrator’s reply.</p></div></div>
  </section>
  <section class="container tx-bottom-cta"><div><span class="tx-section-code">THE DRIVE IS YOURS</span><h2>Where will you go next?</h2><p>Start exploring today. One fleet. Plenty of possibilities.</p></div><a href="<?= h(url('vehicles.php')) ?>" class="tx-button tx-primary">Discover vehicles ↗</a></section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
