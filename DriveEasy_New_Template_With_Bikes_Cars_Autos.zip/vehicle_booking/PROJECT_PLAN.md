# Simple project plan – Phase 1

## Overview

**Project:** DriveEasy Vehicle Booking System.

**Purpose:** Let users find and request vehicles and allow administrators to manage the requests and vehicle details. The project runs locally with XAMPP, PHP, MySQL, plain CSS and JavaScript.

## User stories

- As a **guest**, I can view the home page and vehicle catalogue before creating an account.
- As a **customer**, I can register and log in securely, choose rental dates, make a booking and see its status.
- As a **customer**, I can edit/cancel only my own `pending` booking, and update my profile.
- As an **admin**, I can add/edit/remove vehicles, change booking statuses, manage customers and view dashboard totals.
- As an **admin**, I can read and delete contact enquiries.

## Tables and relationships (ER diagram)

```mermaid
erDiagram
    USERS ||--o{ BOOKINGS : makes
    VEHICLES ||--o{ BOOKINGS : receives
    CATEGORIES ||--o{ VEHICLES : groups
    USERS {
        int id PK
        varchar email UK
        varchar password_hash
        enum role
        bool is_active
    }
    CATEGORIES {
        int id PK
        varchar name UK
    }
    VEHICLES {
        int id PK
        int category_id FK
        varchar registration_no UK
        decimal price_per_day
        bool is_deleted
    }
    BOOKINGS {
        int id PK
        int user_id FK
        int vehicle_id FK
        date pickup_date
        date return_date
        enum status
    }
    MESSAGES {
        int id PK
        varchar email
        text message
    }
```

One user can make many bookings. One vehicle can have many bookings on **non-overlapping active dates**. One category can contain many vehicles. Contact messages stand alone and do not require an account.

## Page flows

Guest → `index.php` → `vehicles.php` → `vehicle_details.php` → `login.php` / `register.php`.

Customer → `login.php` → `vehicle_details.php` → `book.php` → `my_bookings.php` → `edit_booking.php` / `cancel_booking.php`.

Admin → `login.php` → `admin/dashboard.php` → vehicle, booking, customer and message modules.

## Team task split (4 students)

| Member | Main responsibilities | Files |
|---|---|---|
| 1 | Database, registration, login and security | `database/database.sql`, `config/db.php`, `register.php`, `login.php`, `includes/auth.php`, `includes/csrf.php` |
| 2 | Home, vehicle listing, vehicle details and responsive UI | `index.php`, `vehicles.php`, `vehicle_details.php`, `assets/css/style.css`, `assets/js/main.js` |
| 3 | Booking and customer profile | `book.php`, `my_bookings.php`, `edit_booking.php`, `cancel_booking.php`, `profile.php`, `assets/js/booking.js` |
| 4 | Admin panel, testing and documentation | `admin/`, `contact.php`, `SETUP_GUIDE.md`, `TEST_CHECKLIST.md`, `VIVA_QUESTIONS.md` |

Shared integration work: common header/navigation/footer, connecting database, running test cases and final group demonstration.
