# Phase 6 – Manual test checklist

**Important:** The source was syntax-checked, but these functional tests require running XAMPP + MySQL on your computer. Mark Pass or Fail after testing. Do not claim these are already passed.

| ID | Test case | How to test | Expected result | Status |
|---|---|---|---|---|
| 1 | Database import | Import `database.sql` | 5 tables, 12 vehicles, 10 bookings | Not tested |
| 2 | Home | Open `/vehicle_booking/` | Homepage and vehicle cards visible | Not tested |
| 3 | Search/filter | Filter by SUV, seats and max price | Matching vehicles only | Not tested |
| 4 | Register | Create new user with unique email | New customer appears in `users` | Not tested |
| 5 | Duplicate email | Register with existing email | Error; no extra user created | Not tested |
| 6 | Customer login | Use `customer1@vehicle.test` | Customer booking page opens | Not tested |
| 7 | Wrong password | Submit wrong password | Login rejected | Not tested |
| 8 | Admin login | Use admin credentials | Admin dashboard accessible | Not tested |
| 9 | Role protection | Customer visits `/admin/dashboard.php` | HTTP 403; no admin access | Not tested |
| 10 | CSRF | Submit POST without token | HTTP 403 | Not tested |
| 11 | New booking | Book an available vehicle for free dates | Pending booking with correct days and price | Not tested |
| 12 | Double booking | Book dates occupied by pending/approved booking | Overlap error; no second booking | Not tested |
| 13 | Invalid dates | Pickup in past or return before pickup | Error | Not tested |
| 14 | Unavailable car | Try to book maintenance/unavailable car | Booking blocked | Not tested |
| 15 | Cancel pending | Customer cancels own pending booking | Status becomes cancelled | Not tested |
| 16 | Edit own pending | Change dates of own pending booking | Dates and total updated | Not tested |
| 17 | Edit approved | Try to edit approved booking | Blocked | Not tested |
| 18 | Cross-user edit | Use someone else's booking ID | Record not found / change blocked | Not tested |
| 19 | Admin vehicle add | Add a car, optionally upload JPG | Vehicle saved and visible | Not tested |
| 20 | Bad upload | Upload PHP or oversized file | Upload rejected | Not tested |
| 21 | Vehicle edit/delete | Update vehicle, delete without active bookings | Update saved; deleted car hidden | Not tested |
| 22 | Vehicle delete blocked | Delete vehicle with pending/approved booking | Error | Not tested |
| 23 | Admin booking status | Approve a free-dates booking | Status updated | Not tested |
| 24 | Admin approval overlap | Try to approve overlapping rejected booking | Error | Not tested |
| 25 | Admin customer deactivation | Disable customer without active bookings | Login blocked; past history kept | Not tested |
| 26 | Admin customer block | Disable customer with active booking | Error | Not tested |
| 27 | Contact inbox | Send a contact message | Saved to messages; admin can mark read/delete | Not tested |
| 28 | Responsive design | Test 375px, 768px and desktop | Menu and cards readable | Not tested |
| 29 | Output escaping | Enter HTML tags in a message | Displays as text, not executable HTML | Not tested |
| 30 | Logout | Log out and visit protected page | Redirects to login | Not tested |


## Cancellation reason / refund feature tests

| Test | How to test | Expected result |
|---|---|---|
| Pending cancellation reason | Customer submits a pending booking cancellation with under 10 characters | Validation error, booking unchanged |
| Pending booking plus refund | Customer enters reason and checks request refund | Booking cancelled, new pending refund request |
| Approved booking request | Customer requests cancellation and refund | Request pending, booking remains approved until admin decision |
| Owner permission | Customer tries another user's booking id | Request rejected, no record created |
| Duplicate request | Submit refund request again for same booking | Rejected; one refund per booking |
| Admin rejects | Admin writes a 5+ character reason and rejects | Request rejected; customer sees reason; approved booking remains approved |
| Admin approves | Admin verifies payment and approves amount not exceeding booking price | Request approved; booking cancelled; no money moved |
| Admin marks refunded | After external manual transfer, admin enters a reference | Request marked refunded, reference visible to customer |
| Bad refund amount | Admin attempts negative / more than booking price | Rejected by server, no change |
| Deletion guard | Admin tries to delete a booking with refund request | Refused; history retained |
| Data preservation | Import refund_upgrade.sql once into existing DB | Existing bookings/customers remain, 6 tables exist |
