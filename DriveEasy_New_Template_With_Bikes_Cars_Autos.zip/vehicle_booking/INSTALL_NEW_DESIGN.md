# DriveEasy — Toyota-inspired studio design and user photo catalogue

This is a **beginner-friendly university demonstration** using PHP, MySQL, HTML, CSS and plain JavaScript. It does **not** use the Toyota brand or logos. The visual layout is inspired by the white/cyan reference screenshot you supplied.

## What's new

- Compact navigation (69 px initially, 52 px when scrolling).
- White/cyan/black automotive homepage, big editorial headline, split-layout hero and 4 selectable photographs.
- 43 user-provided BikeVault LK motorcycle pictures extracted from your Word document.
- 15 user-provided car, motorbike and three-wheeler pictures extracted from Car images.zip.
- Consistent local WebP images. No external image services, CDN scripts or framework.
- MySQL upgrade for 58 **additional demo catalogue records**. Old 1935–1973 motorcycles are display-only / unavailable by default.
- Catalogue displays vintage entries as **Not bookable**. Other demo vehicles may be booked using the existing customer flow.
- Admin can add/edit/remove vehicles; 1900+ years are supported for vintage demo entries.
- Existing customer accounts, bookings, cancellation/refund workflows and image uploads are preserved by the recommended upgrade workflow.

## Windows / XAMPP — updating an existing installation

1. Start XAMPP and back up `C:\xampp\htdocs\vehicle_booking` (copy the folder somewhere safe). Open phpMyAdmin → `vehicle_booking_db` → Export and save an SQL backup.
2. Extract this ZIP. The new folder is `vehicle_booking`.
3. Copy the CONTENTS of the extracted `vehicle_booking` into your existing `C:\xampp\htdocs\vehicle_booking\`, merging folders and replacing matching code files. **Do not put a second `vehicle_booking` folder inside the first.**
4. If you previously changed `config/db.php` (database username/password or BASE_URL), preserve your configured version. **Do not delete your existing `uploads/vehicles` images**: only add the new images and replace matching demo files.
5. Start Apache and MySQL in XAMPP.
6. Open `http://localhost/phpmyadmin/` and select the EXISTING `vehicle_booking_db` database.
7. Import **only** `database/user_media_upgrade.sql` to add the 58 new demo vehicles. If you never applied `catalog_upgrade.sql` to your older version, apply it first. If the refund tables are still missing, apply `refund_upgrade.sql` following the original setup guide.
8. **Do not import `database.sql` again** into a database containing your live records. Do not drop the database.
9. Open `http://localhost/vehicle_booking/` and press `Ctrl + F5` to refresh CSS/JS. Visit `http://localhost/vehicle_booking/vehicles.php` to see the expanded list.
10. Login as admin and check Admin → Vehicles for the new `BV-DEMO-...` and `PIC-DEMO-...` records. If you need to create a real vehicle, use the Admin Add Vehicle form and enter actual data with a licensed image.

## Fresh XAMPP setup (new empty database)

1. Copy `vehicle_booking/` to `C:\xampp\htdocs\vehicle_booking\`.
2. Start Apache and MySQL. Visit `http://localhost/phpmyadmin/`.
3. Import `database/database.sql` **once** (creates database and base demo records).
4. Import `database/catalog_upgrade.sql` **once** (12 additional demo vehicles and categories).
5. Import `database/user_media_upgrade.sql` **once** (the 58 supplied image examples).
6. Do not run `refund_upgrade.sql` after importing the included `database.sql`, because the base schema already includes the refund table and cancellation field. It is intended for older installations only.
7. In `config/db.php` check `127.0.0.1`, port `3306`, user `root`, password `''` (XAMPP default) and database `vehicle_booking_db`.
8. Open `http://localhost/vehicle_booking/`.

Demo admin login in original project: `admin@vehicle.test` / `Admin@12345` (local development only).

## Where the files live

- `index.php` — new Toyota-inspired homepage, real database featured list
- `vehicles.php` — searchable catalogue (including display-only vintage examples)
- `assets/css/showcase.css` — new styles
- `assets/js/main.js` — compact header / responsive menu / hero image switcher
- `assets/images/showcase-*.webp` — four new hero photographs from your uploaded Car images ZIP
- `uploads/vehicles/uploaded-bike-01.webp` ... `uploaded-bike-43.webp` — all Word document pictures
- `uploads/vehicles/uploaded-showcase-01.webp` ... `uploaded-showcase-15.webp` — all ZIP pictures
- `database/user_media_upgrade.sql` — insert-only MySQL upgrade
- `assets/USER_MEDIA_MANIFEST.csv` — name, category, source label, image mapping

## Limits and safety

- The images were supplied by the user; **image licensing and public redistribution rights have not been independently verified**. This package is for local classroom demonstration unless you have usage rights.
- BikeVault LK distinguishes some pictures as *Photo* and others as *Illustration*. Their labels are recorded in the CSV manifest. Do not claim illustration entries are confirmed photographs of the actual stock.
- New prices, registration numbers, seat counts and rental status are illustrative. They do not confirm actual vehicle ownership, availability or rental eligibility.
- This sample app does not accept payments. A refund approval records a manual decision, not a money transfer.
- Adding physical rental vehicles requires verification, documents, insurance and policies outside this demo.

## Troubleshooting

| Issue | Check |
|---|---|
| `404 Not Found` | Check `C:\xampp\htdocs\vehicle_booking\index.php` exists directly in this path |
| `Failed opening includes/functions.php` | Confirm `vehicle_booking/includes/functions.php` is present; use the **full ZIP** |
| Database connection failed | Start MySQL; check `config/db.php` |
| `Table vehicles doesn't exist` | Import original `database.sql` only for a fresh database |
| New pictures show but no new vehicle cards | Import `user_media_upgrade.sql` into `vehicle_booking_db` |
| Old styles remain | Press `Ctrl + F5`, verify `assets/css/showcase.css` exists |
| File upload fails | Check `uploads/vehicles/` is writable |
| Photos appear incorrectly | Check extracted files are in `uploads/vehicles/` and image names match manifest |

## Basic testing

- Homepage loads with compact header, white/cyan layout, local hero photos, image switch buttons.
- Scroll 40px — header shrinks.
- Category tiles open the corresponding vehicle catalogue filter.
- Search filters by brand/model, date and category.
- New available demo vehicle can be booked. Vintage vehicle shows a not-bookable status and cannot be booked.
- Admin add/edit/remove vehicle, customer login, refund request pages still work.

> This was syntax-checked in a build environment; test actual PHP/MySQL operations in your local XAMPP before submission.
